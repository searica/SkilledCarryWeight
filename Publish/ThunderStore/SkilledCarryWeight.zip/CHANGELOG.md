<table>
	<tbody>
		<tr>
			<th align="center">Version</th>
			<th align="center">Notes</th>
		</tr>
		<tr>
			<td align="center">1.2.0</td>
			<td align="left">
				<ul>
					<li>Compiled against new version and update Jotunn dependency.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.2.0</td>
			<td align="left">
				<ul>
					<li>Added a quick attach/detach option for carts.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.1.2</td>
			<td align="left">
				<ul>
					<li>Bugfix for cart mass not being decreased correctly.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.1.1</td>
			<td align="left">
				<ul>
					<li>Fix README format.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.1.0</td>
			<td align="left">
				<ul>
					<li>Added options to reduce cart mass based on max carry weight.</li>
					<li>Compiled against newest game version.</li>
					<li>Minor performance optimizations.</li>
					<li>Updated icon.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.0/1.0.1</td>
			<td align="left">
				<ul>
					<li>Initial release.</li>
					<li>Add CHANGELOG</li>
				</ul>
			</td>
		</tr>
	</tbody>
</table>
